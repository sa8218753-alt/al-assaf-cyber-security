# Al-Assaf Cyber Security — starter project

A first, mobile-friendly Arabic cybersecurity learning app prototype.

## What's included
- `index.html`: responsive app interface and learning content
- `manifest.json`: basic PWA metadata
- `README.md`: project notes

## Current prototype
Four introductory lessons: cybersecurity basics, networking, Linux, and ethical hacking. Each lesson has a short quiz and progress tracking during the current session.

## Important publishing note
This package is a web app prototype/source package, **not an Android APK or Google Play AAB**. It has no backend, user accounts, cloud sync, or persistent progress yet. To publish on Google Play, it must be packaged as an Android app (for example with a trusted wrapper such as Capacitor or an Android Studio project), tested on devices, and prepared to meet current Play Console requirements. Google Play account and review are managed by the publisher.

## Run
Open `index.html` in a modern browser. For installable PWA behavior, serve the folder over HTTPS or localhost and add service-worker support in a later iteration.
